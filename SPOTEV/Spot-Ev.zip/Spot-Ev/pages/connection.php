<?php
$con = mysqli_connect("localhost","root","","spot_ev");
?>